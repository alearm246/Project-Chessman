import pyxel

class Character:
    def __init__(self):
        self.x = 0
        self.y = 0

class Player (Character):
    def  __init__(self):
        Character.__init__(self)

    def update(self):
        if pyxel.btn(pyxel.KEY_W):
            self.y -= 1
        if pyxel.btn(pyxel.KEY_S):
            self.y += 1
        if pyxel.btn(pyxel.KEY_A):
            self.x -= 1
        if pyxel.btn(pyxel.KEY_D):
            self.x += 1

    def draw(self):
        pyxel.rect(self.x, self.y, self.x + 7, self.y + 7, 10)

class NonPlayer(Character):
    def  __init__(self):
        Character.__init__(self)

    def draw(self):
        pyxel.rect(self.x, self.y, self.x + 7, self.y + 7, 9)

    def update(self):
        pass

class App:
    def __init__(self):
        pyxel.init(160, 120)
        self.player = Player()
        self.npc = NonPlayer()
        pyxel.run(self.update, self.draw)

    def update(self):
        self.player.update()
        self.npc.update()

    def draw(self):
        pyxel.cls(0)
        self.player.draw()
        self.npc.draw()

App()
