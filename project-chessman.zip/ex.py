a = int(input("Input number: "))
b = int(input("Input number: "))

if a < b:
    print("a is less than b")
elif a > b:
    print("a is greater than b")
else:
    print("a is equal to b")
